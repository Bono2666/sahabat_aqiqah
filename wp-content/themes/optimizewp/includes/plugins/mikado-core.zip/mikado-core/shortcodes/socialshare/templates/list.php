<div class="mkdf-social-share-holder mkdf-list">
	<ul>
		<?php foreach ($networks as $net) {
			print optimize_mikado_get_module_part($net);
		} ?>
	</ul>
</div>
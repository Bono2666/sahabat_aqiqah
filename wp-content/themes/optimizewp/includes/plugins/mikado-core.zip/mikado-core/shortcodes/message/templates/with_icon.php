<?php
$icon_html = optimize_mikado_icon_collections()->renderIcon($icon, $icon_pack);
?>

<div class="mkdf-message-icon-holder">
	<div class="mkdf-message-icon" <?php optimize_mikado_inline_style($icon_attributes); ?>>
		<div class="mkdf-message-icon-inner">
			<?php
				print optimize_mikado_get_module_part($icon_html);
			?>			
		</div> 
	</div>	 
</div>


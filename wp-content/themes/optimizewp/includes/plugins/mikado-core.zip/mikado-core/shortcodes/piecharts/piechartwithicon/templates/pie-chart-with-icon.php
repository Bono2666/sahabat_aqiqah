<div class="mkdf-pie-chart-with-icon-holder" <?php echo mkd_core_get_inline_attrs($data_attr); ?>>
	<div class="mkdf-percentage-with-icon" <?php echo optimize_mikado_get_inline_attrs($pie_chart_data); ?>>
		<?php print optimize_mikado_get_module_part($icon); ?>
	</div>
	<div class="mkdf-pie-chart-text" <?php optimize_mikado_inline_style($pie_chart_style)?>>
		<<?php echo esc_html($title_tag)?> class="mkdf-pie-title">
			<?php echo esc_html($title); ?>
		</<?php echo esc_html($title_tag)?>>
		<p><?php echo esc_html($text); ?></p>
	</div>
</div>